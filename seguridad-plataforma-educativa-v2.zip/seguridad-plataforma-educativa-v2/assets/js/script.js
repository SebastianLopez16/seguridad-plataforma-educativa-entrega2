// small client-side polish
document.addEventListener('DOMContentLoaded', function(){
  const forms = document.querySelectorAll('form[novalidate]');
  forms.forEach(f=>{
    f.addEventListener('submit', e=>{
      const invalid = Array.from(f.querySelectorAll('input[required]')).some(i=>!i.value.trim());
      if(invalid){
        e.preventDefault();
        alert('Por favor completa todos los campos requeridos.');
      }
    });
  });
});
