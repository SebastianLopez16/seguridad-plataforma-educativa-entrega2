<?php
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
if(!isset($_SESSION['user_id'])){ header('Location: ../index.php'); exit; }
$user = getUserById($pdo, $_SESSION['user_id']);
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Profesor</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<main class="card">
  <h1>Bienvenido, <?=htmlspecialchars($user['username'])?> (Profesor)</h1>
  <p>Panel de control para profesores.</p>
  <p><a href="../index.php">Cerrar sesión</a></p>
</main>
</body></html>
