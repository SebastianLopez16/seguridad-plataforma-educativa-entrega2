<?php
// This file handles helper functions and small handlers (like resend)
require_once __DIR__ . '/db.php';

function getUserByUsername($pdo, $username){
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    return $stmt->fetch();
}

function getUserById($pdo, $id){
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function save_2fa_code($pdo, $user_id, $code, $expires){
    $stmt = $pdo->prepare('INSERT INTO two_factor (user_id, code, expires_at) VALUES (?, ?, FROM_UNIXTIME(?))');
    $stmt->execute([$user_id, $code, $expires]);
}

function get_last_2fa_code($pdo, $user_id){
    $stmt = $pdo->prepare('SELECT code FROM two_factor WHERE user_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$user_id]);
    $r = $stmt->fetch();
    return $r ? $r['code'] : '';
}

function clear_2fa_code($pdo, $user_id){
    $stmt = $pdo->prepare('DELETE FROM two_factor WHERE user_id = ?');
    $stmt->execute([$user_id]);
}

function validate_2fa_code($pdo, $user_id, $code){
    $stmt = $pdo->prepare('SELECT code, UNIX_TIMESTAMP(expires_at) as expires FROM two_factor WHERE user_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$user_id]);
    $row = $stmt->fetch();
    if(!$row) return false;
    if($row['expires'] < time()) return false;
    return hash_equals((string)$row['code'], (string)$code);
}

function record_login_attempt($pdo, $user_id, $success, $type){
    $stmt = $pdo->prepare('INSERT INTO login_attempts (user_id, success, type, created_at) VALUES (?, ?, ?, NOW())');
    $stmt->execute([$user_id, $success ? 1 : 0, $type]);
}

function lock_user_temporarily($pdo, $user_id, $seconds){
    $stmt = $pdo->prepare('INSERT INTO user_lock (user_id, expires_at) VALUES (?, DATE_ADD(NOW(), INTERVAL ? SECOND))');
    $stmt->execute([$user_id, $seconds]);
}

function is_user_locked($pdo, $user_id){
    $stmt = $pdo->prepare('SELECT COUNT(*) as c FROM user_lock WHERE user_id = ? AND expires_at > NOW()');
    $stmt->execute([$user_id]);
    $r = $stmt->fetch();
    return $r && $r['c'] > 0;
}

// Simple handler for "resend" from verify page via POST
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend_2fa'])){
    session_start();
    if(!isset($_SESSION['2fa_user_id'])){
        header('Location: ../index.php');
        exit;
    }
    $user_id = $_SESSION['2fa_user_id'];
    $code = random_int(100000,999999);
    $_SESSION['2fa_code'] = $code;
    $_SESSION['2fa_expires'] = time() + 300;
    save_2fa_code($pdo, $user_id, $code, $_SESSION['2fa_expires']);
    $_SESSION['flash'] = 'Se reenvió el código (simulado).';
    header('Location: ../verify.php');
    exit;
}
